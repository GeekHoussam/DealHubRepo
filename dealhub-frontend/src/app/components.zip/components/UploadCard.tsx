import React, { useState } from 'react';
import { UploadBox } from './UploadBox';
import { Button } from './Button';
import { toast } from 'sonner';

interface UploadCardProps {
  fileName: string | null;
  status: 'ready' | 'extracting' | 'extracted';
  documentId: string;
  agreementId: string;
  onFileSelect: (file: File) => void;
  onDocumentIdChange: (value: string) => void;
  onAgreementIdChange: (value: string) => void;
  onExtract: () => void;
}

export function UploadCard({
  fileName,
  status,
  documentId,
  agreementId,
  onFileSelect,
  onDocumentIdChange,
  onAgreementIdChange,
  onExtract,
}: UploadCardProps) {
  return (
    <div className="upload-card">
      <div>
        <h2>Upload Facility Agreement</h2>
        <p>Provide a Document ID (backend) and optionally upload a PDF for reference</p>
      </div>

      <div className="form-fields">
        <label>
          Document ID:
          <input type="text" value={documentId} onChange={(e) => onDocumentIdChange(e.target.value)} />
        </label>
        <label>
          Agreement ID:
          <input type="text" value={agreementId} onChange={(e) => onAgreementIdChange(e.target.value)} />
        </label>
      </div>

      <UploadBox onFileSelect={onFileSelect} disabled={status === 'extracting'} />

      <div className="actions">
        <Button onClick={onExtract} disabled={!documentId || !agreementId || status === 'extracting'}>
          {status === 'extracting' ? 'Extracting...' : 'Extract'}
        </Button>
      </div>
    </div>
  );
}
