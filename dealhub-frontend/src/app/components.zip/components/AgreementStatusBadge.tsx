import { clsx } from 'clsx';
import { AgreementStatus } from '../types';

export function AgreementStatusBadge({ status }: { status: AgreementStatus }) {
  const config =
    status === 'VALIDATED'
      ? { bg: 'bg-green-100', text: 'text-green-800', label: 'Validated' }
      : { bg: 'bg-amber-100', text: 'text-amber-800', label: 'Draft' };

  return (
    <span className={clsx('px-3 py-1 rounded-full text-xs font-semibold', config.bg, config.text)}>
      {config.label}
    </span>
  );
}