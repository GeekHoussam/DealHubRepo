import React from 'react';

interface UploadBoxProps {
  onFileSelect: (file: File) => void;
  disabled: boolean;
}

export function UploadBox({ onFileSelect, disabled }: UploadBoxProps) {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files?.length) {
      onFileSelect(event.target.files[0]);
    }
  };

  return (
    <div className="upload-box">
      <input
        type="file"
        accept="application/pdf"
        onChange={handleChange}
        disabled={disabled}
        className="upload-input"
      />
      <p>Drag & drop or browse PDF</p>
    </div>
  );
}
