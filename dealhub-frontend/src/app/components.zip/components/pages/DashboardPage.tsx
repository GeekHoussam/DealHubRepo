import { DashboardTabs } from '../dashboard/DashboardTabs';
import { LenderAgreementsTable } from '../dashboard/LenderAgreementsTable';
import { useAuth } from '../../context/AuthContext';
import { Link } from 'react-router-dom';
import { Button } from '../Button';

export function DashboardPage() {
  const { user } = useAuth();

  if (user?.role === 'LENDER') {
    return (
      <div className="min-h-[calc(100vh-72px)] px-8 py-10">
        <div className="bg-white/90 backdrop-blur rounded-2xl shadow-xl p-6 space-y-4">
          <header>
            <p className="text-sm text-gray-500">Lender dashboard</p>
            <h1 className="text-2xl font-semibold text-gray-900">Validated agreements for my lender</h1>
          </header>
          <LenderAgreementsTable />
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-[calc(100vh-72px)] px-8 py-10 space-y-6 text-white">
      <header className="space-y-1">
        <h1 className="text-3xl font-semibold">Agreement Dashboard</h1>
        <p className="text-blue-100">Manage and review all facility agreements</p>
      </header>
      <DashboardTabs />
      <Link
        to="/extract"
        className="fixed bottom-6 right-6"
      >
        <Button variant="primary" className="shadow-xl shadow-blue-900/30 px-5 py-3 text-base">
          + New Extraction
        </Button>
      </Link>
    </div>
  );
}