import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { AgreementDetailSplitView } from "../detail/AgreementDetailSplitView";
import { AgreementDetailReadOnly } from "../detail/AgreementDetailReadOnly";
import { AuditLogPanel } from "../detail/AuditLogPanel";
import { AgreementVersion, AuditLogEntry } from "../../types";
import { getAudit, getDraftVersion, getValidatedVersion, patchVersion, validateVersion } from "../../api/agreementsApi";
import { useAuth } from "../../context/AuthContext";
import { Button } from "../Button";
import { AgreementStatusBadge } from "../AgreementStatusBadge";

export function AgreementDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [version, setVersion] = useState<AgreementVersion | null>(null);
  const [audit, setAudit] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [validating, setValidating] = useState(false);

  const isLender = user?.role === "LENDER";

  useEffect(() => {
    if (!id) return;

    const fetchData = async () => {
      setLoading(true);
      try {
        const v = isLender ? await getValidatedVersion(id) : await getDraftVersion(id);
        setVersion(v);

        const auditLog = await getAudit(id);
        setAudit(auditLog);
      } catch (error) {
        toast.error("Failed to load agreement");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, isLender]);

  const handleSave = async (payload: any) => {
    if (!version) return;
    setSaving(true);
    try {
      await patchVersion(String(version.agreementId), String(version.id), payload);
      toast.success("Fields saved");

      const refreshed = isLender
        ? await getValidatedVersion(String(version.agreementId))
        : await getDraftVersion(String(version.agreementId));

      setVersion(refreshed);
    } catch {
      toast.error("Unable to save changes");
    } finally {
      setSaving(false);
    }
  };

  const handleValidate = async () => {
    if (!version) return;
    setValidating(true);
    try {
      await validateVersion(String(version.agreementId), String(version.id));
      toast.success("Agreement validated");

      const refreshed = await getValidatedVersion(String(version.agreementId));
      setVersion(refreshed);
    } catch {
      toast.error("Failed to validate agreement");
    } finally {
      setValidating(false);
    }
  };

  if (loading) return <div className="p-6 text-white/80">Loading agreement...</div>;
  if (!version) return <div className="p-6 text-red-200">Agreement not found.</div>;

  const title =
    version.extractedJson?.resultJson?.parties?.borrowerName?.value ??
    `Agreement #${version.agreementId}`;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-white/70">Agreement</p>
          <h1 className="text-2xl font-semibold text-white">{title}</h1>
          <div className="flex items-center gap-2 mt-1">
            <AgreementStatusBadge status={version.status} />
            {version.validatedAt && (
              <p className="text-xs text-white/70">
                Validated on {new Date(version.validatedAt).toLocaleString()}
              </p>
            )}
          </div>
        </div>
        <Button variant="secondary" onClick={() => navigate(-1)}>
          Back
        </Button>
      </div>

      {isLender ? (
        <AgreementDetailReadOnly version={version} />
      ) : (
        <AgreementDetailSplitView
          version={version}
          onSave={handleSave}
          onValidate={handleValidate}
          saving={saving}
          validating={validating}
        />
      )}

      <AuditLogPanel entries={audit} />
    </div>
  );
}
