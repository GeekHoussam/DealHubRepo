import { useMemo, useState } from 'react';
import { UploadCard } from '../UploadCard';
import { ResultsCard } from '../ResultsCard';
import { pollExtraction, startExtraction } from '../../api/extractionsApi';
import { toast } from 'sonner';

function buildValidationIssues(resultJson: any): Array<{ field: string; message: string }> {
  const issues: Array<{ field: string; message: string }> = [];

  const gaps = resultJson?.validationAndGaps;
  if (!gaps) return issues;

  if (Array.isArray(gaps.missingItems)) {
    for (const item of gaps.missingItems) {
      issues.push({ field: 'missing', message: String(item) });
    }
  }
  if (Array.isArray(gaps.nonSearchablePages)) {
    for (const item of gaps.nonSearchablePages) {
      issues.push({ field: 'nonSearchable', message: String(item) });
    }
  }
  if (Array.isArray(gaps.notes)) {
    for (const item of gaps.notes) {
      issues.push({ field: 'notes', message: String(item) });
    }
  }

  return issues;
}

export function ExtractPage() {
  const [fileName, setFileName] = useState<string | null>(null);
  const [status, setStatus] = useState<'ready' | 'extracting' | 'extracted'>('ready');
  const [documentId, setDocumentId] = useState('');
  const [agreementId, setAgreementId] = useState('');
  const [dealSummary, setDealSummary] = useState<{
    dealName: string;
    borrower: string;
    agent: string;
  } | null>(null);
  const [extractedData, setExtractedData] = useState<Record<string, any> | null>(null);
  const [validationIssues, setValidationIssues] = useState<Array<{ field: string; message: string }>>([]);
  const [rawText, setRawText] = useState('');
  const [jobKey, setJobKey] = useState<string | null>(null);

  const canExtract = useMemo(() => {
    const d = Number(documentId);
    const a = Number(agreementId);
    return Number.isFinite(d) && d > 0 && Number.isFinite(a) && a > 0;
  }, [documentId, agreementId]);

  const handleFileSelect = (file: File) => {
    setFileName(file.name);
    setStatus('ready');
    setDealSummary(null);
    setExtractedData(null);
    setValidationIssues([]);
    setRawText('');
    setJobKey(null);
  };

  const handleExtract = async () => {
    if (!canExtract) {
      toast.error('Please enter valid Document ID and Agreement ID');
      return;
    }

    setStatus('extracting');
    setDealSummary(null);
    setExtractedData(null);
    setValidationIssues([]);
    setRawText('');
    setJobKey(null);

    try {
      // If you integrate real auth later, put the bearer token here.
      const token = localStorage.getItem('accessToken') || undefined;

      const started = await startExtraction(
        {
          documentId: Number(documentId),
          agreementId: Number(agreementId),
          extractionProfile: 'FACILITY_AGREEMENT',
        },
        token,
      );

      setJobKey(started.jobKey);
      toast.message('Extraction started', { description: `Job: ${started.jobKey}` });

      const finalJob = await pollExtraction(started.jobKey, { intervalMs: 1500, timeoutMs: 180000 });

      if (finalJob.status === 'FAILED') {
        throw new Error(finalJob.errorMessage || 'Extraction failed');
      }

      const result = finalJob.resultJson || {};
      setExtractedData(result);
      setValidationIssues(buildValidationIssues(result));

      // Best-effort preview values (depends on your backend schema)
      const borrower = result?.parties?.borrower?.legalName?.value ?? result?.parties?.borrowerName;
      const agent = result?.parties?.administrativeAgent?.legalName?.value ?? result?.parties?.administrativeAgentName;
      const dealName = result?.dealName ?? result?.profile ?? 'Facility Agreement';

      setDealSummary({
        dealName: String(dealName),
        borrower: borrower ? String(borrower) : '—',
        agent: agent ? String(agent) : '—',
      });

      setStatus('extracted');
      toast.success('Extraction completed');
    } catch (e: any) {
      console.error(e);
      toast.error('Extraction error', { description: e?.message || String(e) });
      setStatus('ready');
    }
  };

  return (
    <main className="p-6 flex gap-6 max-w-[1440px] mx-auto">
      <UploadCard
        fileName={fileName}
        status={status}
        documentId={documentId}
        agreementId={agreementId}
        dealSummary={dealSummary}
        onFileSelect={handleFileSelect}
        onDocumentIdChange={setDocumentId}
        onAgreementIdChange={setAgreementId}
        onExtract={handleExtract}
      />

      <ResultsCard
        extractedData={extractedData}
        validationIssues={validationIssues}
        rawText={rawText}
      />
    </main>
  );
}