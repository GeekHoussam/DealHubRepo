import { useState } from 'react';
import { Download, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from './Button';
import { Tabs } from './Tabs';
import { RawTextPreview } from './RawTextPreview';

interface ResultsCardProps {
  extractedData: Record<string, any> | null;
  validationIssues: Array<{ field: string; message: string }>;
  rawText: string;
}

export function ResultsCard({ extractedData, validationIssues, rawText }: ResultsCardProps) {
  const [activeTab, setActiveTab] = useState('Extracted JSON');
  const [showRawText, setShowRawText] = useState(false);

  const handleDownloadJSON = () => {
    if (!extractedData) return;
    const blob = new Blob([JSON.stringify(extractedData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'extracted-data.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadCSV = () => {
    if (!extractedData) return;
    const csv = Object.entries(extractedData)
      .map(([key, value]) => `${key},${JSON.stringify(value)}`)
      .join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'extracted-data.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 bg-white rounded-xl shadow-sm p-5 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-base text-[#0B1F3B]">Extracted Output</h2>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={handleDownloadJSON}
            disabled={!extractedData}
            className="flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Download JSON
          </Button>
          <Button
            variant="outline"
            onClick={handleDownloadCSV}
            disabled={!extractedData}
            className="flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Download CSV
          </Button>
        </div>
      </div>

      <Tabs
        tabs={['Extracted JSON', 'Validation']}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <div className="flex-1 min-h-[360px]">
        {activeTab === 'Extracted JSON' ? (
          <div className="bg-gray-50 rounded-lg p-4 h-full overflow-auto">
            {extractedData ? (
              <pre className="text-sm font-mono text-gray-800">
                {JSON.stringify(extractedData, null, 2)}
              </pre>
            ) : (
              <p className="text-sm text-gray-400 text-center py-20">
                No extraction results yet. Upload and extract a PDF to see data here.
              </p>
            )}
          </div>
        ) : (
          <div className="h-full">
            {validationIssues.length > 0 ? (
              <div className="space-y-3">
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm text-orange-800">
                      {validationIssues.length} field{validationIssues.length > 1 ? 's' : ''} require{validationIssues.length === 1 ? 's' : ''} confirmation
                    </p>
                  </div>
                </div>
                <div className="space-y-2">
                  {validationIssues.map((issue, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <p className="text-sm mb-1">
                        <span className="text-gray-600">Field:</span> <code className="bg-gray-100 px-2 py-0.5 rounded text-sm">{issue.field}</code>
                      </p>
                      <p className="text-sm text-gray-600">{issue.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-sm text-gray-400 text-center py-20">
                {extractedData ? 'No validation issues found.' : 'No validation data available yet.'}
              </p>
            )}
          </div>
        )}
      </div>

      <div className="h-px bg-gray-200" />

      <button
        onClick={() => setShowRawText(!showRawText)}
        className="flex items-center justify-center gap-2 text-sm text-[#0B1F3B] hover:text-[#102A52] transition-colors"
      >
        {showRawText ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        {showRawText ? 'Hide' : 'Show'} Raw Text Preview
      </button>

      {showRawText && <RawTextPreview text={rawText} />}
    </div>
  );
}