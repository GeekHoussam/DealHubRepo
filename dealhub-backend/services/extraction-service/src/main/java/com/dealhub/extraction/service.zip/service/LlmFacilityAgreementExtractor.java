package com.dealhub.extraction.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class LlmFacilityAgreementExtractor {

    private final ChatClient chatClient;
    private final ObjectMapper objectMapper;

    // ====== BA consolidated constraints (system contract) ======
    private static final String BA_SYSTEM_RULES = """
        You are a contracts analyst and data extraction engine.

        RULES (critical):
        - Use ONLY the provided document text/chunks. Do not guess.
        - Output MUST be valid JSON only. No markdown. No extra commentary.
        - For EVERY extracted data point, return:
          - value
          - citation (clause/schedule/page reference as stated, e.g., "Clause 2.1", "Schedule 1, Part I", "Definitions 1.1", "front page parties section")
          - evidence (short verbatim quote, max 25 words)
        - If a value is missing OR appears as placeholder (e.g., "[●]", "TBD"), set:
          value = "Not defined / Placeholder"
          and add a brief explanation in the field-level notes (if schema supports notes) or in validationAndGaps.
        - If a relevant section is not searchable (image-only / missing from text), set:
          value = "Non-searchable page—requires transcription"
          and include best-effort page number or section name in citation.
        - Never invent parties, dates, amounts, rates, margins, or clauses.
        """;

    public LlmFacilityAgreementExtractor(ChatClient.Builder chatClientBuilder, ObjectMapper objectMapper) {
        this.chatClient = chatClientBuilder.build();
        this.objectMapper = objectMapper;
    }

    /**
     * @param schema      target JSON schema (string) you want the final output to match exactly
     * @param documentId  document id
     * @param agreementId agreement id
     * @param chunks      text chunks of the PDF
     */
    public JsonNode extract(String schema, long documentId, long agreementId, List<String> chunks) throws Exception {

        // ====== PASS 1: per-chunk structured extraction for BA data points (facts only) ======
        ArrayNode chunkExtractions = objectMapper.createArrayNode();

        for (int i = 0; i < chunks.size(); i++) {
            String chunk = chunks.get(i);

            // Important: Make the chunk task schema-guided, not "any facts"
            String userPrompt = """
                You will extract Facility Agreement data points from ONE chunk of text.

                Chunk index: %d

                DOCUMENT CHUNK:
                <<<CHUNK_START
                %s
                CHUNK_END>>>

                TASK:
                - Produce a JSON object that ONLY contains fields from the target schema below that are supported by this chunk.
                - For every extracted field, include { "value", "citation", "evidence" }.
                - If the chunk contains nothing relevant to any schema field, return {}.

                TARGET SCHEMA (for reference, extract only what you can support from this chunk):
                %s
                """.formatted(i + 1, chunk, schema);

            String raw = chatClient.prompt()
                    .system(BA_SYSTEM_RULES)
                    .user(userPrompt)
                    .call()
                    .content();

            JsonNode one = safeParseJson(raw);
            // ensure object
            if (one != null && one.isObject()) {
                ((ObjectNode) one).put("_chunkIndex", i + 1);
            }
            chunkExtractions.add(one == null ? objectMapper.createObjectNode() : one);
        }

        // ====== PASS 2: merge to final schema EXACTLY ======
        // The merge prompt is the key: force schema exactness + evidence/citation propagation + no invention.
        String mergePrompt = """
            You will receive:
            - documentId=%d
            - agreementId=%d
            - a JSON array of per-chunk extracted objects
            - a target JSON schema

            GOAL:
            - Produce ONE final JSON object that matches the target schema EXACTLY (same structure/keys).
            - Fill values only when supported by extracted chunk objects.
            - If conflicting values exist, choose the one with:
              (1) the most specific citation (e.g. "Clause 2.1" beats "Definitions"),
              (2) the clearest evidence quote,
              and add the discarded alternatives into validationAndGaps.notes if that field exists.
            - Use null when not supported.
            - Never invent values. Never add keys not present in the schema.

            IMPORTANT:
            - Keep {value,citation,evidence} where the schema expects it.
            - Arrays (like lenders) must be deduplicated by legalName/value when possible.

            TARGET SCHEMA:
            %s

            PER-CHUNK EXTRACTS:
            %s
            """.formatted(documentId, agreementId, schema, chunkExtractions.toString());

        String mergedRaw = chatClient.prompt()
                .system(BA_SYSTEM_RULES)
                .user(mergePrompt)
                .call()
                .content();

        JsonNode merged = safeParseJson(mergedRaw);
        if (merged == null || !merged.isObject()) {
            throw new IllegalStateException("LLM merge step did not return a JSON object.");
        }

        ObjectNode mergedObj = (ObjectNode) merged;

        // ====== Force identifiers/profile (only if schema expects them; keep your current behavior but safer) ======
        // If your schema always includes these keys, keep this. If not, you should only set if present in schema.
        mergedObj.put("documentId", documentId);
        mergedObj.put("agreementId", agreementId);

        if (!mergedObj.hasNonNull("profile")) {
            mergedObj.put("profile", "FACILITY_AGREEMENT");
        }

        return mergedObj;
    }

    /**
     * Parses JSON with guardrails for common LLM wrappers (```json ...```) and stray text.
     * Keeps it strict: if it can’t parse, it throws.
     */
    private JsonNode safeParseJson(String raw) throws Exception {
        if (raw == null) return null;

        String s = raw.trim();

        // Strip fenced blocks ```json ... ```
        if (s.startsWith("```")) {
            s = s.replaceFirst("^```[a-zA-Z]*\\s*", "");
            s = s.replaceFirst("\\s*```\\s*$", "");
            s = s.trim();
        }

        // If model returned leading/trailing text, try to isolate the first JSON object/array.
        // (This is safer than regexing everything away.)
        int objStart = s.indexOf('{');
        int arrStart = s.indexOf('[');
        int start = -1;

        if (objStart >= 0 && arrStart >= 0) start = Math.min(objStart, arrStart);
        else if (objStart >= 0) start = objStart;
        else if (arrStart >= 0) start = arrStart;

        if (start > 0) {
            s = s.substring(start).trim();
        }

        // Best-effort trim after last closing brace/bracket
        int objEnd = s.lastIndexOf('}');
        int arrEnd = s.lastIndexOf(']');
        int end = Math.max(objEnd, arrEnd);
        if (end >= 0 && end + 1 < s.length()) {
            s = s.substring(0, end + 1).trim();
        }

        return objectMapper.readTree(s);
    }
}
